from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder, MinMaxScaler
import pandas as pd
import numpy as np
from collections import Counter
import constants as c

def fetchCSV(fileName):
    return pd.read_csv(fileName)

def csvWorker(fileName):
    data_set = pd.read_csv(fileName)
    data_set_X_features = data_set.drop(columns=['id', 'target'])
    data_set_Y_features = data_set['target']
    return [data_set_X_features, data_set_Y_features]

def generateColumnTransformer():
    encoder = ColumnTransformer(
    transformers=[
        ('num', MinMaxScaler(feature_range=(0, 2)), c.NUMERICAL_COLS),
        ('cat', OneHotEncoder(sparse_output=False, handle_unknown='ignore'), c.CATAGORICAL_COLS)
    ])
    return encoder

def caliculateEculidianDistance(trainSet, test):
    return np.linalg.norm(trainSet - test, axis=1)

def caliculateManhattanDistance(trainSet, test):
    return np.sum(np.abs(trainSet - test), axis=1)

def KNN(neighbors, neighborLables, testPoints, k, meter):
    outputs = []
    for tp in testPoints:
        if meter == c.EUCLIDEAN_MAP:
            distances = caliculateEculidianDistance(neighbors, tp)
        elif meter == c.MANHATTAN_MAP:
            distances = caliculateManhattanDistance(neighbors, tp)    
        kNearIndex = np.argpartition(distances, k)[:k]
        kNearLables = neighborLables[kNearIndex]
        most_common_label = Counter(kNearLables).most_common(1)[0][0]
        outputs.append(most_common_label)
    return outputs

def get_third_element(item):
    return item[2]

def sortList(unSorted):
    values = sorted(unSorted, key=get_third_element)
    return values

def formatter(decimal_):
    return "{:.3f}".format(decimal_)

def printer(values):
    for i in range(len(values)):
        k, trainError, devError, pveRatioTrain, pveRatioDev = values[i]
        print('k: ', k, ' T Error Rate: ', trainError, ' (' , pveRatioTrain,') Dev Error Rate: ', devError, ' (', pveRatioDev, ')')



