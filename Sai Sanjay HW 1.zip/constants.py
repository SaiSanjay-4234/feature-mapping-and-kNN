EUCLIDEAN_MAP = 'euclidean'
MANHATTAN_MAP = 'manhattan'

NUMERICAL_COLS =  ['age', 'hours']
CATAGORICAL_COLS = ['sector', 'edu', 'marriage', 'occupation', 'race', 'sex', 'country']

K_MAX = 101

INCOME_TRAIN_5K = 'income.train.5k.csv'
INCOME_DEV = 'income.dev.csv'
INCOME_TEST = 'income.test.blind.csv'

OUTPUT_FILE_NAME = 'manhattan-predictions.csv'