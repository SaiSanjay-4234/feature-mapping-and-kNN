
import pandas as pd
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import accuracy_score
from sklearn.preprocessing import OneHotEncoder, MinMaxScaler
from sklearn.compose import ColumnTransformer
from collections import Counter
import numpy as np
import functions as fn
import constants as c


trSet = fn.fetchCSV(c.INCOME_TRAIN_5K)
dvSet = fn.fetchCSV(c.INCOME_DEV)
xTrSet, yTrSet = fn.csvWorker(c.INCOME_TRAIN_5K)
xDvSet, yDvSet = fn.csvWorker(c.INCOME_DEV)
encoder = fn.generateColumnTransformer()
encoder.fit(trSet)
binXtrSet = encoder.transform(trSet)
binXdvSet = encoder.transform(dvSet)

store = []
k = 1
while k < c.K_MAX:
    pTLables = fn.KNN(binXtrSet, yTrSet, binXtrSet, k, c.MANHATTAN_MAP)
    pDLabels = fn.KNN(binXtrSet, yTrSet, binXdvSet, k, c.MANHATTAN_MAP)
    tAccuracy = accuracy_score(yTrSet, pTLables)    
    dAccuracy = accuracy_score(yDvSet, pDLabels)
    
    tError = 1 - tAccuracy
    dError = 1 - dAccuracy
    
    pTrainRatio = np.mean(np.array(pTLables) == '>50K')
    pDevRatio = np.mean(np.array(pDLabels) == '>50K')
    
    store.append([k, fn.formatter(tError), fn.formatter(dError), fn.formatter(pTrainRatio), fn.formatter(pDevRatio)])
    print('--- Modal predictions on K: {:d} COMPLETED --- '.format(k))
    k += 2
print('\n\n --- K ITERATION COMPLETED \n\n')

sortedStore = fn.sortList(store)
fn.printer(sortedStore)

oK = sortedStore[0][0] 
bTestSet = fn.fetchCSV(c.INCOME_TEST)
tf = bTestSet.drop(columns=['id'])
binary_tf = encoder.transform(tf)

Y_test_pred = fn.KNN(binXtrSet, yTrSet, binary_tf, oK, c.MANHATTAN_MAP)
bTestSet['target'] = Y_test_pred
bTestSet.to_csv(c.OUTPUT_FILE_NAME, index=False)
